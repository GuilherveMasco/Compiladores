Para adicionar o syntax highlighter da linguagem TPP ao Notepad++ siga os seguintes passos:

- Abra o arquivo desejado (.tpp) no Notepad++
- No topo, vá até a aba "Linguagem"
- Desça até "Linguagem definida pelo usuário"
- Selecione "Defina a sua linguagem..."
- Na janela que se abriu, selecione "Importar..."
- Navegue pelos documentos e selecionte o arquivo "TPP_HIGHLIGHTER"
- Após importado, vá novamente até a aba "Linguagem"
- Navegue até as últimas opções, localize e selecione "TPP"
- A linguagem TPP agora será corretamente destacada por cor